document.getElementById('calcularBtn').addEventListener('click', function() {
    const anoAtual = new Date().getFullYear();
    const anoNascimento = document.getElementById("anoNascimento").value;

    const resultado = document.getElementById("resultado");

    if (anoNascimento === "" || anoNascimento > anoAtual || anoNascimento < 1900) {
        resultado.innerText = "Por favor, insira um ano de nascimento existente.";
    } else {
        const idade = anoAtual - anoNascimento;
        resultado.innerText = "Você tem: " + idade + " anos de idade.";
    }
});
