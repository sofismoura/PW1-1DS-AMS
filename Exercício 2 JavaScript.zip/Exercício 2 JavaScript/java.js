document.getElementById('verificarBtn').addEventListener('click', function() {
    const numero = document.getElementById('numero').value;
    const resultado = document.getElementById('resultado');

    if (numero === "") {
        resultado.innerText = "Insira um número:";
    } else 
    
    {
        if (numero % 2 === 0) {
            resultado.innerText = "O número escolhido é par.";

        } 
        
        else 
        
        {
            resultado.innerText = "O número escolhido é ímpar.";
        }

    }
});
